﻿namespace trab_agronomig
{
    partial class uclMenuu
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uclMenuu));
            this.w1 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblQuantVendas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMaior = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dtgsoma = new System.Windows.Forms.DataGridView();
            this.dtgquant = new System.Windows.Forms.DataGridView();
            this.dtgmaior = new System.Windows.Forms.DataGridView();
            this.w1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgsoma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgquant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgmaior)).BeginInit();
            this.SuspendLayout();
            // 
            // w1
            // 
            this.w1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(48)))), ((int)(((byte)(183)))));
            this.w1.Controls.Add(this.lblTotal);
            this.w1.Controls.Add(this.label1);
            this.w1.Controls.Add(this.pictureBox1);
            this.w1.Cursor = System.Windows.Forms.Cursors.Default;
            this.w1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.w1.Location = new System.Drawing.Point(79, 56);
            this.w1.Name = "w1";
            this.w1.Size = new System.Drawing.Size(664, 85);
            this.w1.TabIndex = 0;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(279, 44);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(63, 18);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "lblTotal";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(226, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Total de Dinheiro Ganho";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(152)))), ((int)(((byte)(226)))));
            this.panel1.Controls.Add(this.lblQuantVendas);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.panel1.Location = new System.Drawing.Point(79, 147);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(664, 85);
            this.panel1.TabIndex = 1;
            // 
            // lblQuantVendas
            // 
            this.lblQuantVendas.AutoSize = true;
            this.lblQuantVendas.ForeColor = System.Drawing.Color.White;
            this.lblQuantVendas.Location = new System.Drawing.Point(302, 44);
            this.lblQuantVendas.Name = "lblQuantVendas";
            this.lblQuantVendas.Size = new System.Drawing.Size(80, 18);
            this.lblQuantVendas.TabIndex = 4;
            this.lblQuantVendas.Text = "lblVendas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(226, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantidade de Vendas";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(15, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(125)))), ((int)(((byte)(4)))));
            this.panel2.Controls.Add(this.lblMaior);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.panel2.Location = new System.Drawing.Point(79, 238);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(664, 85);
            this.panel2.TabIndex = 2;
            // 
            // lblMaior
            // 
            this.lblMaior.AutoSize = true;
            this.lblMaior.ForeColor = System.Drawing.Color.White;
            this.lblMaior.Location = new System.Drawing.Point(279, 44);
            this.lblMaior.Name = "lblMaior";
            this.lblMaior.Size = new System.Drawing.Size(68, 18);
            this.lblMaior.TabIndex = 6;
            this.lblMaior.Text = "lblMaior";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(15, 22);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(40, 40);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(268, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Maior Venda";
            // 
            // dtgsoma
            // 
            this.dtgsoma.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgsoma.Location = new System.Drawing.Point(960, 122);
            this.dtgsoma.Name = "dtgsoma";
            this.dtgsoma.Size = new System.Drawing.Size(16, 18);
            this.dtgsoma.TabIndex = 3;
            // 
            // dtgquant
            // 
            this.dtgquant.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgquant.Location = new System.Drawing.Point(964, 104);
            this.dtgquant.Name = "dtgquant";
            this.dtgquant.Size = new System.Drawing.Size(12, 12);
            this.dtgquant.TabIndex = 4;
            // 
            // dtgmaior
            // 
            this.dtgmaior.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgmaior.Location = new System.Drawing.Point(964, 83);
            this.dtgmaior.Name = "dtgmaior";
            this.dtgmaior.Size = new System.Drawing.Size(16, 10);
            this.dtgmaior.TabIndex = 5;
            // 
            // uclMenuu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.dtgmaior);
            this.Controls.Add(this.dtgquant);
            this.Controls.Add(this.dtgsoma);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.w1);
            this.Name = "uclMenuu";
            this.Size = new System.Drawing.Size(821, 342);
            this.Load += new System.EventHandler(this.uclMenuu_Load);
            this.w1.ResumeLayout(false);
            this.w1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgsoma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgquant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgmaior)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel w1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblQuantVendas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblMaior;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dtgsoma;
        private System.Windows.Forms.DataGridView dtgquant;
        private System.Windows.Forms.DataGridView dtgmaior;
    }
}
